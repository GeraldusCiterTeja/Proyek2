import '../styles/styles.css';
import App from './pages/app';
import NavInitiator from './utils/nav-initiator';

const app = new App({
  content: document.querySelector('#mainContent'),
});

const renderApp = () => {
  app.renderPage();
  
  const navContainer = document.querySelector('#navLinks');
  if (navContainer) {
    NavInitiator.init({
      navLinksContainer: navContainer,
    });
  }
};

window.addEventListener('hashchange', renderApp);
window.addEventListener('load', renderApp);